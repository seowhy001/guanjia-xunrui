DROP TABLE IF EXISTS `{dbprefix}guanjiaset`;
