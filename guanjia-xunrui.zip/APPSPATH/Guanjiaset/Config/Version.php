<?php

return [

    'id' => '767',
    'version' => '1.0.0',
    'license' => '',
    'updatetime' => '2022-04-22',
    'downtime' => '2022-04-20',

];
