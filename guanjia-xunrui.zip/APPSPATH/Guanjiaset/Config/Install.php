<?php

// 引导自动安装程序
return [

 'type' => 'app',
 'name' => '搜外内容管家发布插件',

];
