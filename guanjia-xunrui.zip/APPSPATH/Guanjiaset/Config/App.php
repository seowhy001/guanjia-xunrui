<?php

return [

    'type' => 'app',
    'author' => '搜外网',
    'name' => '搜外内容管家发布插件',
    'icon' => 'bi bi-globe2',

];
